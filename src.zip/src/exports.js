export const masonryOptions = {
  fitWidth: true,
  columnWidth: 300,
  gutter: 5
};